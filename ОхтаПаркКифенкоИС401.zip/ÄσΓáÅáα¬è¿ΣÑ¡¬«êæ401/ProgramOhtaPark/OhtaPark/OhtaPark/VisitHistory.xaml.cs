﻿using OhtaPark.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace OhtaPark
{
    public partial class VisitHistory : Window
    {
        OhtaParkPPTRPOEntities db = new OhtaParkPPTRPOEntities();

        public VisitHistory()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            // Загружает список сотрудников из базы данных, учитывая текст поиска.
            var newEmployee = db.Employees
               .Where(c => string.Concat(c.surname.ToLower(), " ", c.name.ToLower(), " ", c.patronymic.ToLower())
                             .Contains(searchTB.Text))
                .ToList();

            if (string.IsNullOrWhiteSpace(searchTB.Text))
                listEntry.ItemsSource = db.Employees.ToList();
            else
                listEntry.ItemsSource = newEmployee;
        }

        private void searchTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();
        }

        private void closeBtn_Click(object sender, RoutedEventArgs e)
        {
            Auth auth = new Auth();
            auth.Show();
            this.Close();
        }
    }
}
