﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OhtaPark
{
    public partial class Captcha : Window
    {
        private string captchaCode;

        public Captcha()
        {
            InitializeComponent();
            GenerateCaptcha();
        }

        private void GenerateCaptcha()
        {
            CaptchaCanvas.Children.Clear();
            Random random = new Random();
            captchaCode = random.Next(1000, 9999).ToString();
            for (int i = 0; i < captchaCode.Length; i++)
            {
                TextBlock textBlock = new TextBlock
                {
                    Text = captchaCode[i].ToString(),
                    FontSize = 30,
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(RandomColor()),
                };

                Canvas.SetLeft(textBlock, 20 + i * 40 + random.Next(-5, 5));
                Canvas.SetTop(textBlock, random.Next(5, 15));
                CaptchaCanvas.Children.Add(textBlock);
            }
            for (int i = 0; i < 5; i++)
            {
                Line line = new Line
                {
                    X1 = random.Next(200),
                    Y1 = random.Next(60),
                    X2 = random.Next(200),
                    Y2 = random.Next(60),
                    Stroke = new SolidColorBrush(RandomColor()),
                    StrokeThickness = 1
                };
                CaptchaCanvas.Children.Add(line);
            }
        }

        private Color RandomColor()
        {
            Random random = new Random();
            return Color.FromRgb((byte)random.Next(256), (byte)random.Next(256), (byte)random.Next(256));
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (CaptchaTextBox.Text == captchaCode)
            {
                MessageBox.Show("Captcha введена верно");
                this.Close();
            }
            else
            {
                MessageBox.Show("Captcha введена неверно. Попробуйте снова.");
                GenerateCaptcha();
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
        }
    }
}
