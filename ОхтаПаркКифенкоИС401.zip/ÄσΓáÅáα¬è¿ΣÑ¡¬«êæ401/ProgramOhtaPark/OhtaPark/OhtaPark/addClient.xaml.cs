﻿using OhtaPark.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace OhtaPark
{
    public partial class addClient : Window
    {
        OhtaParkPPTRPOEntities db = new OhtaParkPPTRPOEntities();
        ClientsOrders clientsOrders;
        public addClient(ClientsOrders CO)
        {
            InitializeComponent();
            clientsOrders = CO;
        }

        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void addBtn_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем валидность данных перед добавлением клиента
            if (isValid())
            {
                // Проверка корректности введённого email
                if (!IsValidEmail(emailTB.Text))
                {
                    MessageBox.Show("Неправильно указана почта");
                    return;
                }

                try
                {
                    // Получаем последнего клиента, чтобы использовать его clientCode для нового клиента
                    var client = db.Clients.OrderByDescending(p => p.clientCode).FirstOrDefault();

                    // Создаём новый объект клиента с введёнными данными
                    var newClient = new Clients
                    {
                        clientCode = client.clientCode + 1,
                        surname = surnameTB.Text,
                        name = nameTB.Text,
                        patronymic = patronymicTB.Text,
                        passportSeries = Convert.ToInt32(passSeriesTB.Text), 
                        passportNumber = Convert.ToInt32(passNumTB.Text),
                        dateOfBirth = bdDatePicker.SelectedDate, 
                        mailIndex = Convert.ToInt32(mailIndexTB.Text),
                        city = cityTB.Text,
                        street = streetTB.Text,
                        houseNumber = houseTB.Text,
                        apartamentNumber = Convert.ToInt32(aptTB.Text), 
                        email = emailTB.Text,
                        password = pwdPB.Password,
                    };

                    // Добавляем нового клиента в базу данных и сохраняем изменения
                    db.Clients.Add(newClient);
                    db.SaveChanges();                    
                    // Перезагружаем данные в списке клиентов
                    clientsOrders.loadData();

                    MessageBox.Show("Клиент добавлен");

                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        public bool IsValidEmail(string email)
        {
            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, pattern);
        }

        public bool isValid() //Метод проверки валидности данных
        {
            if (surnameTB.Text == string.Empty)
            {
                MessageBox.Show("Введите фамилию");
                return false;
            }
            if (nameTB.Text == string.Empty)
            {
                MessageBox.Show("Введите имя");
                return false;
            }
            if (patronymicTB.Text == string.Empty)
            {
                MessageBox.Show("Введите отчество");
                return false;
            }          
            if (passSeriesTB.Text == string.Empty)
            {
                MessageBox.Show("Введите серию паспорта");
                return false;
            }           
            if (passNumTB.Text == string.Empty)
            {
                MessageBox.Show("Введите номер пасспорта");
                return false;
            }           
            if (bdDatePicker.Text == string.Empty)
            {
                MessageBox.Show("Укажите дату");
                return false;
            }
            if (mailIndexTB.Text == string.Empty)
            {
                MessageBox.Show("Введите почтовый индекс");
                return false;
            }
            if (cityTB.Text == string.Empty)
            {
                MessageBox.Show("Введите город");
                return false;
            }
            if (streetTB.Text == string.Empty)
            {
                MessageBox.Show("Введите улицу");
                return false;
            }
            if (houseTB.Text == string.Empty)
            {
                MessageBox.Show("Введите дом");
                return false;
            }
            if (aptTB.Text == string.Empty)
            {
                MessageBox.Show("Введите квартиру");
                return false;
            }
            if (emailTB.Text == string.Empty)
            {
                MessageBox.Show("Введите почту");
                return false;
            }
            if (pwdPB.Password == string.Empty)
            {
                MessageBox.Show("Введите пароль");
                return false;
            }
            return true;
        }

        private void PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !e.Text.All(char.IsDigit);
        }

    }
}
