﻿using OhtaPark.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OhtaPark
{
    public partial class ClientsOrders : Window
    {
        OhtaParkPPTRPOEntities db = new OhtaParkPPTRPOEntities();
        public ClientsOrders()
        {
            InitializeComponent();
            loadData();
        }

        public void loadData() // Загружает список клиентов из базы данных, учитывая текст поиска.
        {
            var searchText = searchTB.Text.ToLower();
            var client = db.Clients
                .Where(c => string.Concat(c.surname.ToLower(), " ", c.name.ToLower(), " ", c.patronymic.ToLower())
                             .Contains(searchText))
                .ToList();

            if (string.IsNullOrWhiteSpace(searchTB.Text))   
                usersList.ItemsSource = db.Clients.ToList(); // Если поле поиска пустое, отображаются все клиенты.
            else
                usersList.ItemsSource = client;
        }
        
        private void searchTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            loadData();
        }

        private void createOrderBtn_Click(object sender, RoutedEventArgs e)
        {
            new addOrder((sender as Button).DataContext as Clients).ShowDialog();
        }

       

        private void addClientBtn_Click(object sender, RoutedEventArgs e)
        {
            addClient ac = new addClient(this);
            ac.ShowDialog();
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            Auth auth = new Auth();
            auth.Show();
            this.Close();
        }
    }
}
