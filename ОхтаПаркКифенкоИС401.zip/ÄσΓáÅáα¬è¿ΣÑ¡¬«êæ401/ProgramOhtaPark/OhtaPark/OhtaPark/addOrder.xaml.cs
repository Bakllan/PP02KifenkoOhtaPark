﻿using OhtaPark.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OhtaPark
{
    public partial class addOrder : Window
    {
        OhtaParkPPTRPOEntities db = new OhtaParkPPTRPOEntities();
        Clients selectedClient;
        public addOrder(Clients clients)
        {
            selectedClient = clients;
            InitializeComponent();
            loadData();
        }

       private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void makeOrdBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int hoursResult = 0;
                int minutesResult = 0;

                // Проверяем, выбраны ли услуги
                if (servicesList.SelectedItems.Count == 0)
                {
                    MessageBox.Show("Добавьте минимум 1 услугу");
                    return;
                }

                // Проверяем, указано ли время
                if (hoursTB.Text == "" && minutesTB.Text == "")
                {
                    MessageBox.Show("Укажите время");
                    return; 
                }

                // Устанавливаем текущее время для заказа
                var orderTime = DateTime.Now;

                // Создаём новый заказ
                var newOrder = new Orders
                {
                    orderCode = selectedClient.clientCode + "/" + orderTime.ToString("dd.MM.yyyy"), 
                    orderDate = orderTime.Date, 
                    orderTime = orderTime.TimeOfDay,
                    clientCode_id = selectedClient.clientCode,
                    status_id = 3,
                    hoursRental = hoursResult,
                    minutesRental = minutesResult 
                };

                // Добавляем новый заказ в базу данных
                db.Orders.Add(newOrder);
                db.SaveChanges();

                foreach (var selectedService in servicesList.SelectedItems)
                {
                    var service = (Services)selectedService;

                    var orderDetail = new Services_Orders
                    {
                        orderCode_id = newOrder.orderCode, // Код заказа
                        service_id = service.id, // ID услуги
                    };

                    // Добавляем услугу в таблицу связей "Услуги-Заказы"
                    db.Services_Orders.Add(orderDetail);
                }

                db.SaveChanges();

                MessageBox.Show("Заказ создан");

                this.Close();
            }
            catch (Exception ex)
            {
                    MessageBox.Show("Возникла ошибка:" + ex);              
            }
        }

        private void loadData()
        {
            var result = db.Services.Where(p => p.serviceName.ToLower().Contains(searchTB.Text.ToLower()) || p.serviceCode.ToLower().Contains(searchTB.Text.ToLower())).ToList();
            if (string.IsNullOrWhiteSpace(searchTB.Text))
                servicesList.ItemsSource = db.Services.ToList();
            else
                servicesList.ItemsSource = result;
        }

        private void searchTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            loadData();
        }
    }
}
