﻿using OhtaPark.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OhtaPark
{
    public partial class Auth : Window
    {
        OhtaParkPPTRPOEntities db = new OhtaParkPPTRPOEntities();
        public Auth()
        {
            InitializeComponent();
        }

        private void enterBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Поиск сотрудника в базе данных с указанными логином и паролем
                var employee = db.Employees
                    .Where(emp => emp.login == loginTB.Text && emp.password == passwordTB.Password)
                    .FirstOrDefault();

                if (employee != null) // Если сотрудник найден
                {
                    // Обновление времени последнего входа и переход на соответствующую форму в зависимости от роли
                    employee.lastEnter = DateTime.Now;
                    db.Employees.AddOrUpdate(employee);
                    db.SaveChanges();

                    if (employee.role_id == 1) // Роль: администратор
                    {
                        VisitHistory vH = new VisitHistory();
                        vH.Show();
                        this.Close();
                    }
                    else if (employee.role_id == 2 || employee.role_id == 3) // Роли: старший смены или продавец
                    {
                        ClientsOrders clord = new ClientsOrders();
                        clord.Show();
                        this.Close();
                    }
                }
                else if (string.IsNullOrWhiteSpace(loginTB.Text) || string.IsNullOrWhiteSpace(passwordTB.Password))
                {
                    // Проверка на заполнение полей
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    // Обработка некорректного логина или пароля
                    MessageBox.Show("Неверно введён логин или пароль");
                    loginTB.Text = "";
                    passwordTB.Password = "";
                    new Captcha().ShowDialog(); // Показ капчи при ошибке
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
